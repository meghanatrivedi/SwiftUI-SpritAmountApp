//
//  AmountSplitApp.swift
//  AmountSplit
//
//  Created by meghana.trivedi on 03/06/24.
//

import SwiftUI

@main
struct AmountSplitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
