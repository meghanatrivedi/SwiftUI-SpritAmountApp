//
//  ContentView.swift
//  AmountSplit
//
//  Created by meghana.trivedi on 03/06/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var checkAmount = ""
       @State private var numberOfPeople = 2
       @State private var selectedTipPercentage = 15
       
       let tipPercentages = [10, 15, 20, 25, 0]
       
       var totalPerPerson: Double {
           let peopleCount = Double(numberOfPeople + 2) // Adding 2 to match the picker range
           let tipSelection = Double(selectedTipPercentage)
           let orderAmount = Double(checkAmount) ?? 0
           
           let tipValue = orderAmount / 100 * tipSelection
           let grandTotal = orderAmount + tipValue
           let amountPerPerson = grandTotal / peopleCount
           
           return amountPerPerson
       }
    
    var body: some View {
        NavigationView {
            Form {
                Section {
                    TextField("Amount", text: $checkAmount)
                        .keyboardType(.decimalPad)
                    
                    Picker("Number of people", selection: $numberOfPeople) {
                        ForEach(2..<100) {
                            Text("\($0)")
                        }
                    }
                }
                
                Section(header: Text("How much tip do you want to leave?")) {
                    Picker("Tip Percentage", selection: $selectedTipPercentage) {
                        ForEach(tipPercentages, id: \.self) {
                            Text("\($0)%")
                        }
                    }
                    .pickerStyle(.segmented)
                }
                
                Section(header: Text("Total amount per person")) {
                    Text("\(totalPerPerson, specifier: "%.2f")")
                }
            }
            .navigationTitle("Amount Split")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
#Preview {
    ContentView()
}
